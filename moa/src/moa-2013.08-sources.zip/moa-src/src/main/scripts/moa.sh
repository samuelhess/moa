#!/bin/bash

java -cp moa.jar -javaagent:sizeofag.jar moa.gui.GUI

