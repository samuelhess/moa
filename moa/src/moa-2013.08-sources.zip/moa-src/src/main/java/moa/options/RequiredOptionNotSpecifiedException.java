package moa.options;


public class RequiredOptionNotSpecifiedException extends Exception {
	private static final long serialVersionUID = 1L;
}
